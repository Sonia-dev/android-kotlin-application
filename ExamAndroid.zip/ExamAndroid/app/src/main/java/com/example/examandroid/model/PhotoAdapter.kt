package com.example.examandroid.model


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.examandroid.R


class PhotoAdapter(private val context: Context, private val photos: List<Photo?>) : RecyclerView.Adapter<PhotoViewHolder>() {

    private lateinit var mlistener: onItemClickListener
    interface  onItemClickListener{

        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(listener :onItemClickListener){
        mlistener=listener
    }




    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):
            PhotoViewHolder {
        // Inflating R.layout.name_item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.recyclerview_layout, parent, false)
        return PhotoViewHolder(view,mlistener)
    }
    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        // Getting element from names list at this position
        val element = photos[position]
        Glide.with(context)
            .load(element?.urls?.regular)
            .into(holder.imageView!!)
        // Updating the text of the txtName with this element
        holder.textView?.text = element?.user?.username
    }
    override fun getItemCount(): Int {
        return photos.size
    }
}
class PhotoViewHolder(itemView: View,listener: PhotoAdapter.onItemClickListener) : RecyclerView.ViewHolder(itemView) {
    var imageView: ImageView? = itemView.findViewById(R.id.imageView)
    var textView: TextView? = itemView.findViewById(R.id.textView)

    init {
        itemView.setOnClickListener{
            listener.onItemClick(adapterPosition)
        }
    }

}