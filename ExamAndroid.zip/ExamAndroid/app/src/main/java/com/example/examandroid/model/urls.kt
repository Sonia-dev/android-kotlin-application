package com.example.examandroid.model

data class urls

        (val raw:String,
         val full:String,
         val small:String,
         val regular:String,
         val thumb:String){
}