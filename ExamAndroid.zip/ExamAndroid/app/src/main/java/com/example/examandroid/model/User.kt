package com.example.examandroid.model

import android.os.Parcelable



data class User (
    val username:String,
    val profile_image: Profile_Image)
{
}