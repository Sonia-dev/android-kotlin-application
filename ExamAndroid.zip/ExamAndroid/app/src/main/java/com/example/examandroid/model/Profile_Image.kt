package com.example.examandroid.model



data class Profile_Image (
     val small:String,
     val large:String,
     val medium:String
         ) {
}