package com.example.examandroid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.annotation.Nullable
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.examandroid.model.Photo
import com.example.examandroid.model.PhotoAdapter
import com.example.examandroid.model.UserAdapter
import com.example.examandroid.viewModel.UserViewModel
import com.example.examandroid.viewModel.photoViewModel
import kotlinx.android.synthetic.main.activity_main.*



class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recycleViewh.setHasFixedSize(true)
        recycleViewh.layoutManager=LinearLayoutManager(this)
        recycleView.setHasFixedSize(true)
        recycleView.layoutManager = LinearLayoutManager(this)
        val model: photoViewModel =
            ViewModelProviders.of(this).get(photoViewModel::class.java)
        model.getPhotos()?.observe(this, object : Observer<List<Photo?>?> {
            override fun onChanged(@Nullable PhotoList: List<Photo?>?) {
                var PhotoAdapter = PhotoAdapter(this@MainActivity, PhotoList!!)
                var UserAdapter=UserAdapter(this@MainActivity,PhotoList!!)
                recycleView.adapter = PhotoAdapter
                recycleViewh.adapter=UserAdapter
                PhotoAdapter.setOnItemClickListener(object :PhotoAdapter.onItemClickListener{
                    override fun onItemClick(position: Int) {
                        Toast.makeText(this@MainActivity,"clicked at , $position ",Toast.LENGTH_SHORT).show()
                    }

                })
            }
        })

    }

}